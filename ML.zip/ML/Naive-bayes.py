import numpy
from sklearn import neighbors, datasets, metrics
from sklearn.model_selection import GridSearchCV

# loading the Iris dataset
X, y = datasets.load_iris(return_X_y=True)

print(X)
print(y)

X_train = X[range(0, 150, 2), :]
y_train = y[range(0, 150, 2)]

X_test = X[range(1, 150, 2), :]
y_test = y[range(1, 150, 2)]

print(X_train)
print(y_train)

print("Testing data")
print(X_test)
print(y_test)

# creating instance of a classifier
clf = neighbors.KNeighborsClassifier();

# param grid should be dictionary or list of dictionaries
# Specify hyperparameters which you want to tune
# If some hyperparamater you don't want to tune, specify that parameter
# while creating instance of the classifier

param_grid = [{'n_neighbors': [1, 5, 10, 20], 'weights': ['uniform', 'distance']}]

# there is a refit argument whose default is True
clf_gs = GridSearchCV(clf, param_grid, cv=5)

clf_gs.fit(X_train, y_train)

# print best parameter
print("Best parameters")
print(clf_gs.best_params_)
'''
Best parameters
{'n_neighbors': 5, 'weights': 'uniform'}
'''
# predict using the learnt classifier
prediction = clf_gs.predict(X_test)

print("-----------------Prediction-------------------")
print(prediction)
print("----------------------------------------------")
'''
-----------------Prediction-------------------
[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 1
 1 1 1 1 2 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2
 2]
----------------------------------------------
'''
print("Accuracy = ", metrics.accuracy_score(y_test, prediction, normalize=True))
'''
Accuracy =  0.9866666666666667
'''
print(metrics.classification_report(y_test, prediction))
'''
              precision    recall  f1-score   support

           0       1.00      1.00      1.00        25
           1       1.00      0.96      0.98        25
           2       0.96      1.00      0.98        25

    accuracy                           0.99        75
   macro avg       0.99      0.99      0.99        75
weighted avg       0.99      0.99      0.99        75

'''
print(metrics.confusion_matrix(y_test, prediction))
'''
[[25  0  0]
 [ 0 24  1]
 [ 0  0 25]]
'''