from sklearn import datasets,svm,metrics

x,y=datasets.load_iris(return_X_y=True)

print(x) #feature data
print(y) #feature data

X_train=x[range(0,150,2),:]
y_train=y[range(0,150,2)]

X_test=x[range(1,150,2),:]
y_test=y[range(1,150,2)]

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)

#now fit Linear SVM that is imported from sklearn
from sklearn.svm import LinearSVC
clf=svm.LinearSVC()
clf.fit(X_train,y_train)

prediction=clf.predict(X_test)
print("Prediction:-",prediction)

print("Acuracy:",metrics.accuracy_score(y_test,prediction,normalize=True))
print(metrics.classification_report(y_test,prediction))
print(metrics.confusion_matrix(y_test,prediction))
