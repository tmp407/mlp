import warnings
warnings.filterwarnings('ignore')
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import seaborn as sn

customers_df=pd.read_csv('Income Data.csv')
print(customers_df.head(5))

sn.lmplot("age","income",data=customers_df,fit_reg=False,size=4)
from sklearn.cluster import KMeans 

clusters=KMeans(3)
clusters.fit(customers_df)
customers_df["clusterid"]=clusters.labels_
print(customers_df.head(5))

Markers=['+','^','*']
sn.lmplot("age","income",data=customers_df,hue="clusterid",fit_reg=False,markers=Markers,size=4)

from sklearn.preprocessing import StandardScaler
scale=StandardScaler()
scaled_customers_df=scale.fit_transform(customers_df[["age","income"]])
print(scaled_customers_df[0:5])

from sklearn.cluster import KMeans
clusters_new=KMeans(3,random_state=42)
clusters_new.fit(scaled_customers_df)
customers_df["clusterid_new"]=clusters_new.labels_

Markers=['+','^','.']
sn.lmplot("age","income",data=customers_df,hue="clusterid_new",fit_reg=False,markers=Markers,size=4)
print(clusters.cluster_centers_)



customers_df.groupby('clusterid')['age','income'].agg(["mean",'std']).reset_index()
