import pandas as pd

pd.set_option('display.float_format',lambda x:'%.3f'% x)
ipl_auc=pd.read_csv('IPL IMB381IPL2013.csv ')

#print(type(ipl_auc))

'''
pd.set_option('display.max_column',2) #show first and last coloums 
print(ipl_auc.head(5))

print(list(ipl_auc.columns))

print(ipl_auc.head(5).transpose())

print(ipl_auc.shape)

print(ipl_auc.info())
'''

print(ipl_auc[0:5])
print(ipl_auc[-5:])
print(ipl_auc['PLAYER NAME'][0:5])
print(ipl_auc.iloc[4:9, 2:4])

# finding unique occurances of values in columns
print(ipl_auc.COUNTRY.value_counts())
'''
IND    53
AUS    22
SA     16
SL     12
PAK     9
NZ      7
WI      6
ENG     3
BAN     1
ZIM     1
Name: COUNTRY, dtype: int64
'''

# convert into percentage
print(ipl_auc.COUNTRY.value_counts(normalize=True) * 100)
'''
IND   40.769
AUS   16.923
SA    12.308
SL     9.231
PAK    6.923
NZ     5.385
WI     4.615
ENG    2.308
BAN    0.769
ZIM    0.769
Name: COUNTRY, dtype: float64
'''

print(pd.crosstab(ipl_auc['AGE'], ipl_auc['PLAYING ROLE']))
'''
PLAYING ROLE  Allrounder  Batsman  Bowler  W. Keeper
AGE                                                 
1                      4        5       7          0
2                     25       21      29         11
3                      6       13       8          1
'''

# SORTING DATAFRAME BY COLUMN VALUES
print(ipl_auc[['PLAYER NAME', 'SOLD PRICE']].sort_values('SOLD PRICE')[0:5])
'''
       PLAYER NAME  SOLD PRICE
73      Noffke, AA       20000
46     Kamran Khan       24000
0      Abdulla, YA       50000
1     Abdur Razzak       50000
118  Van der Merwe       50000
'''
#decending order
print(ipl_auc[['PLAYER NAME', 'SOLD PRICE']].sort_values('SOLD PRICE', ascending=False)[0:5])

#group by
ipl_auc.groupby('AGE')['SOLD PRICE'].mean()
sold_prc = ipl_auc.groupby('AGE')['SOLD PRICE'].mean().reset_index()
print(sold_prc)

sold_prc_by_age_role = ipl_auc.groupby(['AGE','PLAYING ROLE'])['SOLD PRICE'].mean().reset_index()
print(sold_prc_by_age_role)

sold_prc_comparision = sold_prc_by_age_role.merge(sold_prc,on='AGE',how='outer')
print(sold_prc_comparision)

# sold_prc_comparision.rename(columns={ 'SOLD PRICE_x': 'SOLD_PRICE_AGE_ROLE', 'SOLD PRICE_y': 'SOLD_PRICE_AGE_ROLE'})
# print(sold_prc_comparision.head())

# sold_prc_comparision['change'] = sold_prc_comparision.apply(lambda rec:(rec.SOLD_PRICE_AGE_ROLE - rec.SOLD_PRICE_AGE_ROLE))
# print(sold_prc_comparision)

#Condition 
print(ipl_auc[ipl_auc['SIXERS'] > 80][['PLAYER NAME','SIXERS']])

#Drop column 
ipl_auc.drop('Sl.NO.',inplace=True,axis=1)
print(ipl_auc.head())
