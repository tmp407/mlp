import matplotlib.pyplot as plt
import seaborn as sn
import numpy as np
from numpy import linalg as LA
import pandas as pd

pd.set_option('display.float_format',lambda x:'%.3f' %x)
ipl_auction_df = pd.read_csv('IPL IMB381IPL2013.csv')
ipl_auction_df.groupby('AGE')['SOLD PRICE'].mean()
soldprice_by_age = ipl_auction_df.groupby('AGE')['SOLD PRICE'].mean().reset_index()
print(soldprice_by_age)
sn.barplot(x='AGE',y='SOLD PRICE',data=soldprice_by_age)
plt.show()

sold_price_by_age_role = ipl_auction_df.groupby(['AGE', 'PLAYING ROLE'])['SOLD PRICE'].mean().reset_index()
print(sold_price_by_age_role)

sold_price_comparison = sold_price_by_age_role.merge(sold_price_by_age, on='AGE', how='outer')
print(sold_price_comparison)'''
sold_price_comparison.rename(columns={'SOLD PRICE_x': 'SOLD_PRICE_AGE_ROLE', 'SOLD PRICE_y': 'SOLD_PRICE_AGE'},
                             inplace=True)
print(sold_price_comparison)

sn.barplot(x='AGE', y='SOLD_PRICE_AGE_ROLE', hue='PLAYING ROLE', data=sold_price_comparison)
plt.show()

plt.hist(ipl_auction_df['SOLD PRICE'])
plt.show()

plt.hist(ipl_auction_df['SOLD PRICE'], bins=20)
plt.show()

sn.distplot(ipl_auction_df['SOLD PRICE'])
plt.show()

box = plt.boxplot(ipl_auction_df['SOLD PRICE'])
plt.show()

print([item.get_ydata()[0] for item in box['caps']])
print([item.get_ydata()[0] for item in box['whiskers']])
print([item.get_ydata()[0] for item in box['medians']])

print(ipl_auction_df[ipl_auction_df['SOLD PRICE'] > 1350000.0][['PLAYER NAME', 'AGE']])

sn.boxplot(x='PLAYING ROLE', y='SOLD PRICE', data=ipl_auction_df)

ipl_batsman_df = ipl_auction_df[ipl_auction_df['PLAYING ROLE'] == 'Batsman']
plt.scatter(x=ipl_batsman_df.SIXERS, y=ipl_batsman_df['SOLD PRICE'])
plt.xlabel('SIXERS')
plt.ylabel('SOLD PRICE')
plt.show()

sn.regplot(x='SIXERS', y='SOLD PRICE', data=ipl_auction_df)
plt.show()
