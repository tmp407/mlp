import numpy;
from sklearn import neighbors, datasets, metrics
from sklearn.model_selection import GridSearchCV

X, y=datasets.load_iris(return_X_y=True)

print(X)

print(y)

X_train=X[range(0,150,2), :]
y_train=y[range(0,150,2)]

X_test=X[range(1,150,2),:]
y_test=y[range(0,150,2)]

print(X_train)
print(y_train)

print("testing data")
print(X_test)
print(y_test)

clf = neighbors.KNeighborsClassifier()

param_grid = [
    { 'n_neighbors' : [ 1, 5, 10, 20 ], 'weights': ['uniform','distance']  }
]

clf_gs = GridSearchCV(clf, param_grid,cv=5)
clf_gs.fit(X_train, y_train)

print("Best Parms: ")
print(clf_gs.best_params_)

prediction = clf_gs.predict(X_test) 


print("#### -prediction- ####")
print(prediction)
