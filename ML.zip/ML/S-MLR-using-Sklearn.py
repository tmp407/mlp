import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np

np.set_printoptions(precision=4, linewidth=100)
mba_salary_df=pd.read_csv("MBA Salary.csv")
print(mba_salary_df.head(10))
print(mba_salary_df.info())

#statistical library
import statsmodels.api as sn
x=sn.add_constant(mba_salary_df['Percentage in Grade 10'])
x.head(5)
y=mba_salary_df['Salary']
print(x)
print(y)
from sklearn.model_selection import train_test_split
train_x,test_x,train_y,test_y = train_test_split(x,y,train_size=0.8,random_state=100)

print("train-x")
print("TrainX", train_x)
print("TextX", test_x)

print("train-y")
print("TrainY", train_y)
print("TextY", test_y)

mba_salary_lm=sn.OLS(train_y, train_x).fit()
print("value of intercept d slope")
print(mba_salary_lm.params) #value of intercept d slope

pred_Y = mba_salary_lm.predict(test_x)

#store

pred_Y_df = pd.DataFrame({'grade_10_perc': test_x['Percentage in Grade 10'], 'pred_Y': pred_Y, })

print("pred_Y_df")
print(pred_Y_df[0:10])
from sklearn.metrics import r2_score, mean_squared_error
print('R2 Score',np.abs(r2_score(test_y,pred_Y)))
print('MSE',np.sqrt(mean_squared_error(test_y,pred_Y)))




