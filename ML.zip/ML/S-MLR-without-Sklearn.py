#1. Identify the rows where 'horse power' has missing value in auto.mpg dataset 
#2. Drop these rows
#3. substitue the Identified missing values rows with mean/ median/ mode from the dataset
#4. from the list of the part Identify the similar values and substitute mean of the risk part of the dataset with these Identified rows

import pandas as pd

autos = pd.read_csv('auto-mpg.csv') # creating dataframe
missing_values_horsepower = autos[(autos["horsepower"].isnull())] # fetching null values using isnull function
print(missing_values_horsepower)
autos_mean=autos["horsepower"].mean() #calculating mean of horsepower column values
autos["horsepower"].fillna(value=autos_mean, inplace=True) #filling values by it's mean
# missing_values = autos[(autos["horsepower"].isnull())]
# print(missing_values)

print(autos)
print(autos.head(5))
print(autos.info())

# import pandas as pd
# import numpy as np

# autos = pd.read_csv('auto-mpg.csv')
# autos_temp = autos
# print(autos)

# print(autos[autos['horsepower'].isnull()])

# autos.fillna(autos.mean())

# autos_temp.dropna()
# print(autos_temp)

auto_dp = autos[autos['cylinders'].duplicated()]
print(auto_dp)
mean_cy = auto_dp['cylinders'].mean()
auto_dp['cylinders'].replace({"8":mean_cy,"4":mean_cy}, inplace = True)