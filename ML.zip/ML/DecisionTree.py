import pandas as pd
from sklearn.model_selection import train_test_split

credit_df = pd.read_csv("German Credit Data.csv")
credit_df.info()
credit_df.iloc[0:5, 1:7]
credit_df.iloc[0:5, 7:]

credit_df.status.value_counts()

x_features = list(credit_df.columns)
x_features.remove('status')

encoded_credit_df = pd.get_dummies(credit_df[x_features], drop_first=True)
list(encoded_credit_df)

encoded_credit_df[['checkin_acc_A12', 'checkin_acc_A13', 'checkin_acc_A14']].head(5)

y = credit_df.status
x = encoded_credit_df

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42)

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
from sklearn import tree
from sklearn.tree import export_graphviz
clf_tree = DecisionTreeClassifier(criterion='gini', max_depth=3)
clf_tree.fit(X_train, y_train)

tree_predict = clf_tree.predict(X_test)
roc_auc_score(y_test, tree_predict)

tree.plot_tree(clf_tree)
'''# Export the tree into odt file
export_graphviz(clf_tree, out_file="chd_tree.odt", feature_names=X_train.columns,class_namea=['Good Creadit', 'Bad Credit'], filled=True)

# Read the create the image file
import pydot as pdot
chd_tree_graph = pdot.graphviz.graph_from_dot_file('chd_tree.odt')
'''